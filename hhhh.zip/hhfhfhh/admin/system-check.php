<?php
require __DIR__ . '/../bootstrap.php';
hs_require_admin();

if (!defined('HDSPTV_VALIDATOR_EMBEDDED')) {
    define('HDSPTV_VALIDATOR_EMBEDDED', true);
}

$data = require __DIR__ . '/../tools/validate_hdsptv_integrity.php';

$status = is_array($data) ? ($data['status'] ?? 'error') : 'error';
$errors = is_array($data) ? ($data['errors'] ?? []) : ['Unable to run integrity validator.'];
$warnings = is_array($data) ? ($data['warnings'] ?? []) : [];
$syntaxFailures = is_array($data) ? ($data['syntax_failures'] ?? []) : [];
$checkedPhpFiles = is_array($data) ? (int)($data['checked_php_files'] ?? 0) : 0;
$checkedSourceFiles = is_array($data) ? (int)($data['checked_source_files'] ?? 0) : 0;

hs_admin_shell_start('System Check · HDSPTV Admin', 'System Check', 'system');
?>
<section class="admin-grid cols-3">
  <div class="metric-card">
    <span class="label">Validator status</span>
    <strong><?= $status === 'ok' ? 'Healthy' : 'Attention needed' ?></strong>
    <small><?= $status === 'ok' ? 'All required files, links, routes and PHP syntax checks passed.' : 'One or more directory, route, link or syntax checks failed.' ?></small>
  </div>
  <div class="metric-card">
    <span class="label">PHP files checked</span>
    <strong><?= $checkedPhpFiles ?></strong>
    <small>Validated with PHP lint.</small>
  </div>
  <div class="metric-card">
    <span class="label">Source files checked</span>
    <strong><?= $checkedSourceFiles ?></strong>
    <small>Links, routes and assets were scanned.</small>
  </div>
</section>

<section class="admin-card">
  <div class="admin-card-header">
    <h2>Integrity validator</h2>
    <div class="header-actions">
      <a class="btn btn-secondary" href="<?= hs_admin_url('system-check.php') ?>">Run again</a>
      <a class="btn btn-primary" href="<?= hs_base_url('tools/validate_hdsptv_integrity.php?format=json') ?>" target="_blank" rel="noopener">Open raw report</a>
    </div>
  </div>

  <?php if ($status === 'ok'): ?>
    <div class="notice success">The file directory structure, routes, links, scripts, and core assets are connected correctly.</div>
  <?php else: ?>
    <div class="notice danger">The validator found issues. Review the errors below and fix them before deployment.</div>
  <?php endif; ?>

  <div class="system-list">
    <?php foreach ($errors as $error): ?>
      <div class="system-item error"><?= htmlspecialchars((string)$error) ?></div>
    <?php endforeach; ?>
    <?php if (!$errors): ?>
      <div class="system-item success">No directory, route, link, asset, or syntax issues were detected.</div>
    <?php endif; ?>
  </div>
</section>

<?php if (!empty($warnings)): ?>
<section class="admin-card">
  <div class="admin-card-header">
    <h2>Warnings</h2>
  </div>
  <div class="system-list">
    <?php foreach ($warnings as $warning): ?>
      <div class="system-item"><?= htmlspecialchars((string)$warning) ?></div>
    <?php endforeach; ?>
  </div>
</section>
<?php endif; ?>

<?php if (!empty($syntaxFailures)): ?>
<section class="admin-card">
  <div class="admin-card-header">
    <h2>PHP syntax failures</h2>
  </div>
  <div class="system-list">
    <?php foreach ($syntaxFailures as $file => $message): ?>
      <div class="system-item error">
        <strong><?= htmlspecialchars((string)$file) ?></strong><br>
        <small><?= htmlspecialchars((string)$message) ?></small>
      </div>
    <?php endforeach; ?>
  </div>
</section>
<?php endif; ?>

<section class="admin-card">
  <div class="admin-card-header">
    <h2>What this checks</h2>
  </div>
  <ul class="checklist">
    <li>Required directories and required files exist in the expected places.</li>
    <li>Registered routes point to files or supported virtual targets.</li>
    <li>Page links, script tags, forms, fetch calls, and CSS asset references resolve correctly.</li>
    <li>PHP files pass syntax validation with <code>php -l</code>.</li>
  </ul>
</section>
<?php hs_admin_shell_end(); ?>
