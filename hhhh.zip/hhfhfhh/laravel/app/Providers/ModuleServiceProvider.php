<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\File;

class ModuleServiceProvider extends ServiceProvider
{
    public function register()
    {
        $modulePath = base_path('../app/Modules');
        
        if (File::exists($modulePath)) {
            $modules = File::directories($modulePath);
            foreach ($modules as $module) {
                $bootFile = $module . '/module.php';
                if (File::exists($bootFile)) {
                    require_once $bootFile;
                }
            }
        }
    }

    public function boot()
    {
        //
    }
}
