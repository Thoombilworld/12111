<?php

namespace App\Http\Controllers;

use App\Models\Post;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function index()
    {
        $posts = Post::with('category')
            ->where('status', 'published')
            ->orderBy('created_at', 'desc')
            ->limit(18)
            ->get();

        return view('frontend.home', compact('posts'));
    }
}
