<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Session;

class LocalizationMiddleware
{
    public function handle(Request $request, Closure $next)
    {
        $locale = Session::get('hs_locale', config('app.locale', 'en'));
        
        if ($request->has('lang')) {
            $locale = $request->query('lang');
            Session::put('hs_locale', $locale);
        }

        App::setLocale($locale);

        return $next($request);
    }
}
