<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class Post extends Model
{
    protected $table = 'hs_posts';

    protected $fillable = [
        'title', 'slug', 'content', 'excerpt', 'image_main', 'category_id', 
        'status', 'type', 'is_featured', 'is_breaking', 'is_trending', 'created_at'
    ];

    public function category(): BelongsTo
    {
        return $this->belongsTo(Category::class, 'category_id');
    }

    public function tags(): BelongsToMany
    {
        return $this->belongsToMany(Tag::class, 'hs_post_tags', 'post_id', 'tag_id');
    }
}
