<?php

declare(strict_types=1);

$root = dirname(__DIR__);
chdir($root);

$errors = [];
$warnings = [];
$checkedPhpFiles = [];
$syntaxFailures = [];

function err(array &$errors, string $message): void
{
    $errors[] = $message;
}


function warn(array &$warnings, string $message): void
{
    $warnings[] = $message;
}


function resolve_php_binary(): ?string
{
    $candidates = [];

    if (defined('PHP_BINARY') && is_string(PHP_BINARY) && PHP_BINARY !== '') {
        $candidates[] = PHP_BINARY;
    }

    if (defined('PHP_BINDIR') && is_string(PHP_BINDIR) && PHP_BINDIR !== '') {
        $candidates[] = rtrim(PHP_BINDIR, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . 'php';
        $candidates[] = rtrim(PHP_BINDIR, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . 'php.exe';
    }

    foreach ($candidates as $candidate) {
        if (is_file($candidate)) {
            return $candidate;
        }
    }

    return null;
}


function syntax_check_file(string $file, array &$warnings): ?string
{
    if (strtolower(pathinfo($file, PATHINFO_EXTENSION)) !== 'php') {
        return null;
    }

    static $phpBinary = null;
    static $binaryResolved = false;
    static $warningIssued = false;

    if (!$binaryResolved) {
        $phpBinary = resolve_php_binary();
        $binaryResolved = true;
    }

    if (!is_string($phpBinary) || $phpBinary === '') {
        if (!$warningIssued) {
            warn($warnings, 'PHP CLI binary unavailable. Syntax lint checks were skipped.');
            $warningIssued = true;
        }
        return null;
    }

    $cmd = escapeshellarg($phpBinary) . ' -l ' . escapeshellarg($file) . ' 2>&1';
    $output = shell_exec($cmd);
    if (!is_string($output)) {
        if (!$warningIssued) {
            warn($warnings, 'PHP CLI lint command could not be executed. Syntax lint checks were skipped.');
            $warningIssued = true;
        }
        return null;
    }

    if (stripos($output, 'No syntax errors detected') !== false) {
        return null;
    }

    return trim($output);
}

function maybe_json_output(array $payload): void
{
    $format = strtolower(trim($_GET['format'] ?? ($_SERVER['argv'][1] ?? '')));
    if ($format !== 'json') {
        return;
    }

    if (!headers_sent()) {
        header('Content-Type: application/json; charset=utf-8');
    }

    echo json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    exit;
}


function normalize_path(string $path): string
{
    $path = str_replace('\\', '/', $path);
    $path = preg_replace('#/+#', '/', $path) ?? $path;
    $segments = [];

    foreach (explode('/', $path) as $segment) {
        if ($segment === '' || $segment === '.') {
            continue;
        }
        if ($segment === '..') {
            array_pop($segments);
            continue;
        }
        $segments[] = $segment;
    }

    return implode('/', $segments);
}

function should_skip_reference(string $value): bool
{
    $value = trim($value);
    if ($value === '' || $value === '/' || $value[0] === '#') {
        return true;
    }

    if (preg_match('#^(https?:)?//#i', $value) === 1) {
        return true;
    }

    if (preg_match('#^(mailto:|tel:|javascript:|data:)#i', $value) === 1) {
        return true;
    }

    if (str_contains($value, '<?') || str_contains($value, '?>')) {
        return true;
    }

    if (str_contains($value, '{{') || str_contains($value, '}}')) {
        return true;
    }

    if (str_contains($value, '{') || str_contains($value, '}')) {
        return true;
    }

    if (str_contains($value, '$')) {
        return true;
    }

    return false;
}

function clean_reference(string $value): string
{
    $value = trim($value);
    $value = preg_replace('/[#?].*$/', '', $value) ?? $value;
    return trim($value);
}


function strip_php_blocks(string $content): string
{
    return preg_replace('/<\?(?:php|=)?[\s\S]*?\?>/i', ' ', $content) ?? $content;
}

function candidate_paths(string $reference, string $sourceFile): array
{
    $reference = clean_reference($reference);
    if ($reference === '') {
        return [];
    }

    $baseDir = normalize_path(dirname($sourceFile));
    $paths = [];

    if ($reference[0] === '/') {
        $paths[] = normalize_path(substr($reference, 1));
    } else {
        $paths[] = normalize_path(($baseDir === '.' ? '' : $baseDir . '/') . $reference);
        $paths[] = normalize_path($reference);
    }

    return array_values(array_unique(array_filter($paths, static fn (string $p): bool => $p !== '')));
}

function path_exists_with_fallbacks(string $path): bool
{
    if ($path === '') {
        return true;
    }

    if (is_file($path) || is_dir($path)) {
        return true;
    }

    if (is_file($path . '.php')) {
        return true;
    }

    if (is_file($path . '/index.php')) {
        return true;
    }

    return false;
}


function include_candidate_paths(string $reference, string $sourceFile, bool $usesDirConstant): array
{
    $reference = trim($reference);
    if ($reference === '') {
        return [];
    }

    $baseDir = normalize_path(dirname($sourceFile));

    if ($usesDirConstant) {
        return [
            normalize_path(($baseDir === '.' ? '' : $baseDir . '/') . ltrim($reference, '/')),
        ];
    }

    if (preg_match('#^(?:[A-Za-z]:)?/#', $reference) === 1) {
        return [normalize_path(ltrim($reference, '/'))];
    }

    return array_values(array_unique([
        normalize_path(($baseDir === '.' ? '' : $baseDir . '/') . $reference),
        normalize_path($reference),
    ]));
}


function include_reference_resolves(string $reference, string $sourceFile, bool $usesDirConstant): bool
{
    foreach (include_candidate_paths($reference, $sourceFile, $usesDirConstant) as $candidate) {
        if (is_file($candidate)) {
            return true;
        }
    }

    return false;
}

function reference_resolves(string $reference, string $sourceFile, array $routeTargetCandidates, array $virtualTargets): bool
{
    $candidates = candidate_paths($reference, $sourceFile);
    foreach ($candidates as $candidate) {
        $trimmed = trim($candidate, '/');
        if (
            path_exists_with_fallbacks($candidate)
            || in_array($trimmed, $routeTargetCandidates, true)
            || in_array($trimmed, $virtualTargets, true)
        ) {
            return true;
        }
    }

    return false;
}

function collect_source_files(array $extensions): array
{
    $files = [];
    $iterator = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator('.', FilesystemIterator::SKIP_DOTS)
    );

    foreach ($iterator as $item) {
        if (!$item->isFile()) {
            continue;
        }

        $path = str_replace('\\', '/', $item->getPathname());
        if (str_starts_with($path, './.git/')) {
            continue;
        }

        $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
        if (in_array($ext, $extensions, true)) {
            $files[] = ltrim($path, './');
        }
    }

    sort($files);
    return $files;
}

$requiredDirs = [
    'admin',
    'admin/content',
    'app',
    'app/Modules',
    'app/Modules/Admin',
    'app/Modules/Content',
    'app/Views',
    'app/Views/frontend',
    'assets/css',
    'assets/images',
    'assets/js',
    'assets/images/icons',
    'auth',
    'config',
    'docs',
    'install',
    'laravel',
    'tools',
    'writable/logs',
    'writable/uploads/images',
];

$requiredFiles = [
    '.htaccess',
    'bootstrap.php',
    'config/config.php',
    'index.php',
    'post.php',
    'category.php',
    'tag.php',
    'search.php',
    'about.php',
    'contact.php',
    'gallery.php',
    'live.php',
    'notifications.php',
    'profile.php',
    'saved.php',
    'sitemap.php',
    'trending.php',
    'video.php',
    'robots.php',
    'offline.html',
    'manifest.webmanifest',
    'service-worker.js',
    'README.md',
    'README_INSTALL.txt',
    'admin/_layout.php',
    'admin/index.php',
    'admin/login.php',
    'admin/content/articles.php',
    'app/Modules/Admin/module.php',
    'app/Modules/Content/module.php',
    'app/Views/frontend/home.php',
    'assets/css/style.css',
    'assets/js/pwa.js',
    'assets/images/icons/icon-192.svg',
    'assets/images/icons/icon-512.svg',
    'install/index.php',
    'install/install.sql',
    'tools/validate_hdsptv_integrity.php',
];

foreach ($requiredDirs as $dir) {
    if (!is_dir($dir)) {
        err($errors, "Missing required directory: {$dir}");
    }
}

foreach ($requiredFiles as $file) {
    if (!is_file($file)) {
        err($errors, "Missing required file: {$file}");
    }
}

require_once $root . '/bootstrap.php';
$routes = function_exists('hs_routes') ? hs_routes() : [];
$routeTargetCandidates = [];
$virtualTargets = ['sitemap.xml', 'robots.txt'];

if (empty($routes)) {
    err($errors, 'Route registry (hs_routes) is empty or unavailable.');
} else {
    foreach ($routes as $name => $path) {
        if (!is_string($path) || trim($path) === '') {
            err($errors, "Route '{$name}' has invalid empty path.");
            continue;
        }

        $normalized = ltrim(trim($path), '/');
        $normalized = preg_replace('/:[A-Za-z0-9_]+/', '', $normalized) ?? $normalized;
        $normalized = trim((string) $normalized, '/');

        if ($normalized !== '') {
            $routeTargetCandidates[] = $normalized;
        }

        if (str_contains($path, ':')) {
            continue;
        }

        if ($path === '/' || $normalized === '') {
            continue;
        }

        if (!path_exists_with_fallbacks($normalized)) {
            err($errors, "Route '{$name}' points to non-existing path: {$path}");
        }
    }
}

$routeTargetCandidates = array_values(array_unique($routeTargetCandidates));

$sourceFiles = collect_source_files(['php', 'html', 'js', 'css']);

$routePattern = "/hs_route\\(['\"]([^'\"]+)['\"]/";
$basePattern = "/hs_base_url\\(['\"]([^'\"]+)['\"]/";
$adminPattern = "/hs_admin_url\\(['\"]([^'\"]*)['\"]/";
$adminContentPattern = "/hs_admin_content_url\\(['\"]([^'\"]*)['\"]/";

$htmlReferencePatterns = [
    '/(?:href|src|action|poster|data-src|data-href)\\s*=\\s*["\\\']([^"\\\']+)["\\\']/i',
];

$jsReferencePatterns = [
    '/(?:fetch|register|importScripts)\\(\\s*["\\\']([^"\\\']+)["\\\']/i',
];

$cssReferencePatterns = [
    '/url\\(\\s*["\\\']?([^"\\\')]+)["\\\']?\\s*\\)/i',
];

$includePattern = '/(?:require|require_once|include|include_once)\s*(?:\(\s*)?(?:(__DIR__)\s*\.\s*)?["\\\']([^"\\\']+)["\\\']/i';

foreach ($sourceFiles as $file) {
    $content = @file_get_contents($file);
    if ($content === false) {
        err($errors, "Unable to read source file: {$file}");
        continue;
    }

    if (preg_match_all($routePattern, $content, $matches)) {
        foreach ($matches[1] as $routeName) {
            if (!isset($routes[$routeName])) {
                err($errors, "{$file}: unknown route name '{$routeName}' in hs_route().");
            }
        }
    }

    if (preg_match_all($basePattern, $content, $matches)) {
        foreach ($matches[1] as $path) {
            if (should_skip_reference($path)) {
                continue;
            }

            if (!reference_resolves($path, $file, $routeTargetCandidates, $virtualTargets)) {
                err($errors, "{$file}: unresolved hs_base_url path '{$path}'.");
            }
        }
    }

    if (preg_match_all($adminPattern, $content, $matches)) {
        foreach ($matches[1] as $path) {
            $path = trim($path);
            if ($path === '') {
                $path = 'index.php';
            } elseif (!str_contains($path, '.')) {
                $path .= '.php';
            }

            $full = 'admin/' . ltrim($path, '/');
            if (!is_file($full)) {
                err($errors, "{$file}: unresolved hs_admin_url path '{$full}'.");
            }
        }
    }

    if (preg_match_all($adminContentPattern, $content, $matches)) {
        foreach ($matches[1] as $path) {
            $path = trim($path);
            if ($path === '') {
                $path = 'index.php';
            } elseif (!str_contains($path, '.')) {
                $path .= '.php';
            }

            $full = 'admin/content/' . ltrim($path, '/');
            if (!is_file($full)) {
                err($errors, "{$file}: unresolved hs_admin_content_url path '{$full}'.");
            }
        }
    }

    $extension = strtolower(pathinfo($file, PATHINFO_EXTENSION));
    $scanContent = $extension === 'php' ? strip_php_blocks($content) : $content;

    if ($extension === 'php' && preg_match_all($includePattern, $content, $includeMatches, PREG_SET_ORDER)) {
        foreach ($includeMatches as $includeMatch) {
            $usesDirConstant = !empty($includeMatch[1]);
            $reference = trim((string) ($includeMatch[2] ?? ''));
            if ($reference === '' || str_contains($reference, '$')) {
                continue;
            }

            if (!include_reference_resolves($reference, $file, $usesDirConstant)) {
                err($errors, "{$file}: unresolved include target '{$reference}'.");
            }
        }
    }

    $referencePatterns = [];
    if ($extension === 'php' || $extension === 'html') {
        $referencePatterns = $htmlReferencePatterns;
    } elseif ($extension === 'js') {
        $referencePatterns = $jsReferencePatterns;
    } elseif ($extension === 'css') {
        $referencePatterns = $cssReferencePatterns;
    }

    foreach ($referencePatterns as $pattern) {
        if (!preg_match_all($pattern, $scanContent, $matches)) {
            continue;
        }

        foreach ($matches[1] as $reference) {
            if (should_skip_reference($reference)) {
                continue;
            }

            if (!reference_resolves($reference, $file, $routeTargetCandidates, $virtualTargets)) {
                err($errors, "{$file}: unresolved static reference '{$reference}'.");
            }
        }
    }

    if ($extension === 'php' || $extension === 'html') {
        foreach ($jsReferencePatterns as $pattern) {
            if (!preg_match_all($pattern, $scanContent, $matches)) {
                continue;
            }

            foreach ($matches[1] as $reference) {
                if (should_skip_reference($reference)) {
                    continue;
                }

                if (!reference_resolves($reference, $file, $routeTargetCandidates, $virtualTargets)) {
                    err($errors, "{$file}: unresolved script reference '{$reference}'.");
                }
            }
        }
    }
}

$manifestPath = 'manifest.webmanifest';
if (is_file($manifestPath)) {
    $manifest = json_decode((string) file_get_contents($manifestPath), true);
    if (!is_array($manifest)) {
        err($errors, 'manifest.webmanifest is not valid JSON.');
    } else {
        foreach (['start_url', 'scope'] as $key) {
            if (empty($manifest[$key]) || !is_string($manifest[$key])) {
                continue;
            }

            $reference = $manifest[$key];
            if (should_skip_reference($reference)) {
                continue;
            }

            if (!reference_resolves($reference, $manifestPath, $routeTargetCandidates, $virtualTargets)) {
                err($errors, "manifest.webmanifest: unresolved {$key} '{$reference}'.");
            }
        }

        if (!empty($manifest['icons']) && is_array($manifest['icons'])) {
            foreach ($manifest['icons'] as $icon) {
                if (!is_array($icon) || empty($icon['src']) || !is_string($icon['src'])) {
                    err($errors, 'manifest.webmanifest: icon entry missing valid src.');
                    continue;
                }

                $candidates = candidate_paths($icon['src'], $manifestPath);
                $found = false;
                foreach ($candidates as $candidate) {
                    if (path_exists_with_fallbacks($candidate)) {
                        $found = true;
                        break;
                    }
                }
                if (!$found) {
                    err($errors, "manifest.webmanifest: unresolved icon src '{$icon['src']}'.");
                }
            }
        }

        if (!empty($manifest['shortcuts']) && is_array($manifest['shortcuts'])) {
            foreach ($manifest['shortcuts'] as $shortcut) {
                if (!is_array($shortcut) || empty($shortcut['url']) || !is_string($shortcut['url'])) {
                    err($errors, 'manifest.webmanifest: shortcut entry missing valid url.');
                    continue;
                }

                if (!reference_resolves($shortcut['url'], $manifestPath, $routeTargetCandidates, $virtualTargets)) {
                    err($errors, "manifest.webmanifest: unresolved shortcut url '{$shortcut['url']}'.");
                }
            }
        }
    }
}

$swPath = 'service-worker.js';
if (is_file($swPath)) {
    $swContent = (string) file_get_contents($swPath);
    if (preg_match('/STATIC_ASSETS\\s*=\\s*\\[(.*?)\\];/s', $swContent, $matches)) {
        preg_match_all('/["\\\']([^"\\\']+)["\\\']/', $matches[1], $assetMatches);
        foreach ($assetMatches[1] as $assetPath) {
            if (should_skip_reference($assetPath)) {
                continue;
            }

            if (!reference_resolves($assetPath, $swPath, $routeTargetCandidates, $virtualTargets)) {
                err($errors, "service-worker.js: unresolved STATIC_ASSETS entry '{$assetPath}'.");
            }
        }
    } else {
        err($errors, 'service-worker.js: STATIC_ASSETS array not found.');
    }

    if (preg_match_all('/\b(?:icon|badge)\s*:\s*["\\\']([^"\\\']+)["\\\']/', $swContent, $assetMatches)) {
        foreach ($assetMatches[1] as $assetPath) {
            if (should_skip_reference($assetPath)) {
                continue;
            }

            if (!reference_resolves($assetPath, $swPath, $routeTargetCandidates, $virtualTargets)) {
                err($errors, "service-worker.js: unresolved notification asset '{$assetPath}'.");
            }
        }
    }

    if (preg_match_all('/\burl\s*:\s*(?:[A-Za-z0-9_.$]+\s*\|\|\s*)?["\\\']([^"\\\']+)["\\\']/', $swContent, $urlMatches)) {
        foreach ($urlMatches[1] as $targetPath) {
            if (should_skip_reference($targetPath)) {
                continue;
            }

            if (!reference_resolves($targetPath, $swPath, $routeTargetCandidates, $virtualTargets)) {
                err($errors, "service-worker.js: unresolved notification url '{$targetPath}'.");
            }
        }
    }
}

$errors = array_values(array_unique($errors));
sort($errors);


foreach ($sourceFiles as $file) {
    if (strtolower(pathinfo($file, PATHINFO_EXTENSION)) !== 'php') {
        continue;
    }
    $checkedPhpFiles[] = $file;
    $lint = syntax_check_file($file, $warnings);
    if ($lint !== null) {
        $syntaxFailures[$file] = $lint;
        err($errors, "PHP syntax error in {$file}: {$lint}");
    }
}

$summary = [
    'status' => empty($errors) ? 'ok' : 'error',
    'checked_php_files' => count($checkedPhpFiles),
    'checked_source_files' => count($sourceFiles),
    'syntax_failures' => $syntaxFailures,
    'errors' => $errors,
    'warnings' => $warnings,
];

if (defined('HDSPTV_VALIDATOR_EMBEDDED') && HDSPTV_VALIDATOR_EMBEDDED) {
    return $summary;
}

if (defined('HDSPTV_VALIDATOR_EMBEDDED') && HDSPTV_VALIDATOR_EMBEDDED) {
    return $summary;
}

maybe_json_output($summary);

if (!empty($errors)) {
    fwrite(STDERR, "HDSPTV integrity validation failed:\n");
    foreach ($errors as $error) {
        fwrite(STDERR, " - {$error}\n");
    }
    exit(1);
}

echo "HDSPTV integrity validation passed. Checked " . count($checkedPhpFiles) . " PHP files and " . count($sourceFiles) . " source files.\n";
