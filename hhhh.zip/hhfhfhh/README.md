# HDSPTV

HDSPTV is a PHP-based international news platform build with a public-facing website, newsroom admin panel, multilingual support, responsive layouts, and Progressive Web App features.

## File directory validation and automated checks

This build includes a validated file directory structure with automated integrity checks so pages, scripts, assets, and routes stay connected.

### Included validator
- `tools/validate_hdsptv_integrity.php` scans:
  - required directories
  - required files
  - registered routes
  - page links and asset references
  - PHP syntax with `php -l`

### Admin access
- `admin/system-check.php` runs the validator and displays the result inside the admin panel.

### CLI usage
```bash
php tools/validate_hdsptv_integrity.php
php tools/validate_hdsptv_integrity.php json
```

### What to verify before deployment
1. The integrity validator passes.
2. Admin pages open from the sidebar without redirect loops.
3. Public pages load their CSS, JavaScript, images, and forms correctly.
4. PHP syntax failures are fixed before publishing.

